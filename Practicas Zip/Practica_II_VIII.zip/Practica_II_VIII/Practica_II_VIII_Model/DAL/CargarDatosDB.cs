﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Practica_II_VIII_Model.Models;

namespace Practica_II_VIII_Model.DAL
{
    public class CargarDatosDB : System.Data.Entity.DropCreateDatabaseIfModelChanges<EstudiantesContext>
    {
        protected override void Seed(EstudiantesContext context)
        {
            var estudiantes = new List<Estudiante>()
            {
                new Estudiante{Nombre="Vicente", Apellidos="Luna", Fecha_Inscripcion= DateTime.Parse("1996-03-27")},
                new Estudiante{Nombre="Juan", Apellidos="Luna", Fecha_Inscripcion= DateTime.Parse("2002-06-23")},
                new Estudiante{Nombre="Estefany", Apellidos="Luna", Fecha_Inscripcion= DateTime.Parse("1992-03-24")},
                new Estudiante{Nombre="Angelica", Apellidos="Luna", Fecha_Inscripcion= DateTime.Parse("1997-06-01")},
                new Estudiante{Nombre="Adoni", Apellidos="Luna", Fecha_Inscripcion= DateTime.Parse("2003-10-17")}

            };

            estudiantes.ForEach(e => context.Estudiantes.Add(e));

            var cursos = new List<Curso>()
            {
                new Curso{CursoID=1,Descripcion="Programacion",},
                new Curso{CursoID=2,Descripcion="Base de Datos",},
                new Curso{CursoID=3,Descripcion="Ciberseguridad",},
                new Curso{CursoID=4,Descripcion="Auditoria de Sistemas",},
                new Curso{CursoID=5,Descripcion="Redes",}

            };

            cursos.ForEach(c => context.Cursos.Add(c));

            var inscripcions = new List<Inscripcion>()
            {
                new Inscripcion {Semestre = 2019, CursoId = 1, EstudianteId = 2 },
                new Inscripcion {Semestre = 2018, CursoId = 2, EstudianteId = 1},
                new Inscripcion {Semestre = 2020, CursoId = 3, EstudianteId = 2},
            };

            inscripcions.ForEach(i => context.Inscripcions.Add(i));

        }
    }
}
