﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Practica_1_MVC.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public string Index()
        {
            return "<html><body>" +
                    "<h1>Universidad Autonoma Santo Domingo(UASD)</h1>" +
                    "<p>Diplomado Desarrollo Web C#, MVC </p>" +
                    "</body></html>";
        }
        public string DiplomadoWeb()
        {
            return "<html><body>" +
                    "<h1>Estudiantes:</h1>" +
                    "<p>Yorqui Montero Sanchez<br>"+
                    "Junior Maria Araujo<br>"+
                    "Marileidy Manzueta De La Rosa<br>"+
                    "Vicente Luna</p>" +
                    "</body></html>";
        }

    }
}