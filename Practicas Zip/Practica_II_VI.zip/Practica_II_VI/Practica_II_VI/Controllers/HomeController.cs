﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Practica_II_VI.Models;

namespace Practica_II_VI.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {

            RegistroProductos rp = new RegistroProductos();
            return View(rp.VerProductos());
        }

        public ActionResult Agregar()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Agregar(FormCollection collection)
        {
            RegistroProductos rp = new RegistroProductos();
            Producto producto = new Producto
            {
                Descripcion = collection["Descripcion"],
                Tipo = collection["Tipo"],
                Precio = float.Parse(collection["Precio"]),
            };
            rp.AgregarProducto(producto);
            return RedirectToAction("Index");
        }
        public ActionResult Borrar(int id)
        {
            RegistroProductos rp = new RegistroProductos();
            rp.BorrarProducto(id);
            return RedirectToAction("Index");
        }

        public ActionResult Modificar(string descripcion)
        {
            RegistroProductos rp = new RegistroProductos();
            Producto p = rp.BucarProducto(descripcion);
            return View(p);
        }

        [HttpPost]
        public ActionResult Modificar(FormCollection collection)
        {
            RegistroProductos rp = new RegistroProductos();
            Producto p = new Producto
            {
                IdProducto = int.Parse(collection["IdProducto"]),
                Descripcion = collection["Descripcion"],
                Tipo = collection["Tipo"],
                Precio = float.Parse(collection["Precio"]),
            };
            rp.ModificarProducto(p);
            return RedirectToAction("Index");
        }

    }
}