﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Practica_II_VI.Models
{
    public class RegistroProductos
    {
        private SqlConnection con;

        private void Conectar()
        {
            string conectar = ConfigurationManager.ConnectionStrings["ConexionDB"].ToString();
            con = new SqlConnection(conectar);
        }

        public int AgregarProducto(Producto product)
        {
            Conectar();
            SqlCommand comando = new SqlCommand("Insert into Productos (Descripcion, Tipo, Precio)" +
                "Values(@Descripcion, @Tipo, @Precio)", con);

            comando.Parameters.Add("@Descripcion", SqlDbType.VarChar);
            comando.Parameters.Add("@Tipo", SqlDbType.VarChar);
            comando.Parameters.Add("@Precio", SqlDbType.Float);

            comando.Parameters["@Descripcion"].Value = product.Descripcion;
            comando.Parameters["@Tipo"].Value = product.Tipo;
            comando.Parameters["@Precio"].Value = product.Precio;

            con.Open();
            int i = comando.ExecuteNonQuery();
            con.Close();

            return i;
        }

        public List<Producto> VerProductos()
        {
            Conectar();
            List<Producto> productos = new List<Producto>();

            SqlCommand comando = new SqlCommand("Select * from Productos", con);
            con.Open();

            SqlDataReader registros = comando.ExecuteReader();
            while (registros.Read())
            {
                Producto product = new Producto();
                {
                    product.IdProducto = int.Parse(registros["IdProducto"].ToString());
                    product.Descripcion = registros["Descripcion"].ToString();
                    product.Tipo = registros["Tipo"].ToString();
                    product.Precio = float.Parse(registros["Precio"].ToString());
                };
                productos.Add(product);
            }
            con.Close();
            return productos;
        } 


        public Producto BucarProducto(string descripcion)
        {
            Conectar();
            SqlCommand comando = new SqlCommand("Select * from Productos " + 
                                                 "Where Descripcion=@Descripcion", con);

            comando.Parameters.Add("@Descripcion", SqlDbType.VarChar);
            comando.Parameters["@Descripcion"].Value = descripcion;
            
            con.Open();
            SqlDataReader registros = comando.ExecuteReader();
            Producto product = new Producto();
            if (registros.Read())
            {                   
                {
                    product.IdProducto = int.Parse(registros["IdProducto"].ToString());
                    product.Descripcion = registros["Descripcion"].ToString();
                    product.Tipo = registros["Tipo"].ToString();
                    product.Precio = float.Parse(registros["Precio"].ToString());
                };
            }
            con.Close();
            return product;
        }
        
        public int ModificarProducto(Producto producto)
        {
            Conectar();
            SqlCommand comando = new SqlCommand("UPDATE Productos SET Descripcion=@Descripcion, Tipo=@Tipo, Precio=@Precio "+
                                                "WHERE IdProducto=@IdProducto", con);

            comando.Parameters.Add("@IdProducto", SqlDbType.Int);
            comando.Parameters["@IdProducto"].Value = producto.IdProducto;
            comando.Parameters.Add("@Descripcion", SqlDbType.VarChar);
            comando.Parameters["@Descripcion"].Value = producto.Descripcion;
            comando.Parameters.Add("@Tipo", SqlDbType.VarChar);
            comando.Parameters["@Tipo"].Value = producto.Tipo;
            comando.Parameters.Add("@Precio", SqlDbType.Float);
            comando.Parameters["@Precio"].Value = producto.Precio;

            con.Open();
            int i = comando.ExecuteNonQuery();
            con.Close();

            return i;
        }
        
        public int BorrarProducto(int codigo)
        {
            Conectar();
            SqlCommand comando = new SqlCommand("DELETE from Productos where IdProducto=@IdProducto",con);

            comando.Parameters.Add("@IdProducto", SqlDbType.Int);
            comando.Parameters["@IdProducto"].Value = codigo;

            con.Open();
            int i = comando.ExecuteNonQuery();
            con.Close();

            return i;
        }

    }
}