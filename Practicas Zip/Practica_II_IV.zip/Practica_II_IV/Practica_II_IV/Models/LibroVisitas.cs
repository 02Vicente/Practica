﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Web.Hosting;


namespace Practica_II_IV.Models
{
    public class LibroVisitas
    {
        public void Grabar(string nombre, string cedula, string telefono, string correo, string comentarios)
        {
            StreamWriter archivo = new StreamWriter(HostingEnvironment.MapPath("~")+"/App_Data/datos.txt",true);
            archivo.WriteLine("Nombre: " + nombre + "<br>Cedula: " + cedula + "<br> Telefono: " + telefono 
                + "<br> Correo: " + correo + "<br> Comentarios: " + comentarios + "<hr>");
            archivo.Close();
        }

        public string Leer()
        {
            StreamReader archivo = new StreamReader(HostingEnvironment.MapPath("~") + "/App_Data/datos.txt");
            string todo = archivo.ReadToEnd();
            archivo.Close();
            return todo;
        }

    }
}