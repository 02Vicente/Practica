﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Practica_II_III.Models;

namespace Practica_II_III.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            var persona = new List<Persona>
            {
                new Persona {Nombre ="Vicente", Apellido="Luna", Edad=23 , Sexo="Masculino"},
                new Persona {Nombre ="Estefany", Apellido="Luna", Edad=27 , Sexo="Femenino"},
                new Persona {Nombre ="JuanAntonio", Apellido="Luna", Edad=17 , Sexo="Masculino"},
                new Persona {Nombre ="Angelica", Apellido="Luna", Edad=22 , Sexo="Femanino"},
                new Persona {Nombre ="Adoni", Apellido="Luna", Edad=16 , Sexo="Masculino"},
            };

            return View(persona);
        }

        
    }
}