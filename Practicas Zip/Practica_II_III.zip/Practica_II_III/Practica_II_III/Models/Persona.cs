﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Practica_II_III.Models
{
    public class Persona
    {
        public string Nombre { get; set; }
        public string  Apellido { get; set; }
        public int Edad { get; set; }
        public string Sexo { get; set; }

    }
}